# Flutter---WatchList
<h1 align="center">Residência Porto Digital</h1>
 


## Descrição:

<p>Projeto de residência do Porto Digital, desenvolvido em Flutter por alunos do Embarque Digital da faculdade Senac.</p>

## :handshake: Colaboradores
<table>
  <tr>
    <td align="center">Anderson Veloso</td>
    <td align="center">Cleber Rosa</td>
    <td align="center">João Vitor</td>
    <td align="center">Rebeka Dias</td>
    <td align="center">Sophia Albuquerque</td>
  </tr>
</table>
