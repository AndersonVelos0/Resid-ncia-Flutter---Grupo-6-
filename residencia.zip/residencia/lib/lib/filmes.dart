import 'package:oficina_flutter/screens/modelo/classificacao.dart';
import 'package:oficina_flutter/screens/modelo/base_filme.dart';
import 'package:residencia/lib/screens/modelo/classificacao.dart';

List<Filme> filmeItem = [
  Filme(
    nome: "Coringa",
    classificacao: Classification.naoRecomendado18,
    duracao: "02:02h",
    sinopse:
        "Isolado, intimidado e desconsiderado pela sociedade, o fracassado comediante Arthur Fleck inicia seu caminho como uma mente criminosa após assassinar três homens em pleno metrô. Sua ação inicia um movimento popular contra a elite de Gotham City, da qual Thomas Wayne é seu maior representante.",
    genero: "Suspense",
    linkImagem:
        "https://upload.wikimedia.org/wikipedia/pt/thumb/6/63/Joker_%282019%29.jpg/250px-Joker_%282019%29.jpg",
    sessao: [
      "14:00",
      "16:00",
      "19:00",
    ],
  ),
  Filme(
    nome: "Toy Story 4",
    classificacao: Classification.livre,
    duracao: "1:40h",
    sinopse:
        "Agora morando na casa da pequena Bonnie, Woody apresenta aos amigos o novo brinquedo construído por ela: Forky, baseado em um garfo de verdade. O novo posto de brinquedo não o agrada nem um pouco, o que faz com que Forky fuja de casa. Decidido a trazer de volta o atual brinquedo favorito de Bonnie, Woody parte em seu encalço e, no caminho, reencontra Bo Peep, que agora vive em um parque de diversões.",
    genero: "Animação",
    linkImagem:
        "https://th.bing.com/th/id/OIP.iun3gO_5K7PMT2Zn7PioiwDcFG?rs=1&pid=ImgDetMain",
    sessao: [
      "14:00",
      "16:00",
      "19:00",
    ],
  ),
  Filme(
    nome: "Vingadores Ultimato",
    classificacao: Classification.naoRecomendado12,
    duracao: "03:02h",
    sinopse:
        "Após Thanos eliminar metade das criaturas vivas, os Vingadores têm de lidar com a perda de amigos e entes queridos. Com Tony Stark vagando perdido no espaço sem água e comida, Steve Rogers e Natasha Romanov lideram a resistência contra o titã louco.",
    genero: "Ação",
    linkImagem:
        "https://upload.wikimedia.org/wikipedia/pt/thumb/9/9b/Avengers_Endgame.jpg/250px-Avengers_Endgame.jpg",
    sessao: [
      "14:00",
      "16:00",
      "19:00",
    ],
  ),
  Filme(
    nome: "Pantera Negra",
    classificacao: Classification.naoRecomendado12,
    duracao: "2:14h",
    sinopse:
        "T'Challa retorna para a isolada e avançada nação africana de Wakanda para assumir o trono como rei após a morte de seu pai. No entanto, ele logo descobre que desafios surgem quando um antigo inimigo reaparece e coloca em perigo o destino de Wakanda e do mundo.",
    genero: "Ação",
    linkImagem:
        "https://cdn.awsli.com.br/600x700/1610/1610163/produto/177685265/poster-pantera-negra-b-953cc034.jpg",
    sessao: [
      "15:00",
      "17:30",
      "20:15",
    ],
  ),
  Filme(
    nome: "O Senhor dos Anéis: A Sociedade do Anel",
    classificacao: Classification.naoRecomendado12,
    duracao: "2:58h",
    sinopse:
        "Um jovem hobbit chamado Frodo recebe um anel mágico de seu tio Bilbo, desencadeando uma jornada épica para destruir o anel e impedir o retorno do maligno Senhor das Trevas Sauron.",
    genero: "Fantasia",
    linkImagem:
        "https://th.bing.com/th/id/R.7836a26a8af8e62de36d84216aaca7f7?rik=r6E4sJ12Oz%2bBBA&riu=http%3a%2f%2fbr.web.img3.acsta.net%2fmedias%2fnmedia%2f18%2f92%2f91%2f32%2f20224832.jpg&ehk=RUj44Sh2FpGHLd0Hxh9fmLNrCU1kn%2bf0AxWDyl7Ljl4%3d&risl=&pid=ImgRaw&r=0",
    sessao: [
      "14:30",
      "17:00",
      "20:00",
    ],
  ),
  Filme(
    nome: "Jurassic Park",
    classificacao: Classification.naoRecomendado12,
    duracao: "2:07h",
    sinopse:
        "Um excêntrico bilionário convida um grupo de cientistas para visitar um parque de dinossauros geneticamente recriados, mas as coisas saem terrivelmente erradas quando os dinossauros escapam de seus confinamentos.",
    genero: "Aventura",
    linkImagem:
        "https://filmartgallery.com/cdn/shop/products/Jurassic-Park-Vintage-Movie-Poster-Original-Belgian-14x22.jpg?v=1652850308",
    sessao: [
      "14:15",
      "16:45",
      "19:30",
    ],
  ),
];
