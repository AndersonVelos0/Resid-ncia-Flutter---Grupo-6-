import 'package:oficina_flutter/screens/modelo/classificacao.dart';
import 'package:residencia/lib/screens/modelo/classificacao.dart';

class Filme {
  String nome;
  Classification classificacao;
  String duracao;
  String sinopse;
  String genero;
  String linkImagem;
  List<String> sessao;

  Filme({
    required this.nome,
    required this.classificacao,
    required this.duracao,
    required this.sinopse,
    required this.genero,
    required this.linkImagem,
    required this.sessao,
  });
}
