import 'package:flutter/material.dart';
import 'package:oficina_flutter/filmes.dart';
import 'package:oficina_flutter/screens/filme_style.dart';
import 'package:oficina_flutter/screens/modelo/base_filme.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    List<Filme> filmes = filmeItem;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(136, 0, 255, 1),
        elevation: 6,
        title: const Text(
          'Recine',
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: GridView.builder(
        itemCount: filmes.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          childAspectRatio: 0.70,
        ),
        itemBuilder: (context, index) => Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            children: [
              SizedBox(
                height: MediaQuery.sizeOf(context).height * 0.27,
                width: 200,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return Film(
                            filme: filmes[index],
                          );
                        },
                      ),
                    );
                  },
                  child: Card(
                    clipBehavior: Clip.hardEdge,
                    elevation: 4,
                    child: Image.network(
                      filmes[index].linkImagem,
                      height: double.infinity,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              Text(
                filmes[index].nome,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.normal,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
