import 'package:flutter/material.dart';
import 'screens/tela_inicial.dart'; // Importe a sua HomeScreen aqui

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Residência Loomi',
      theme: ThemeData.dark(), // Definindo o tema como dark diretamente aqui
      home: HomeScreen(),
    );
  }
}

@override
Widget build(BuildContext context) {
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Residência',
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(
        seedColor: Color.fromARGB(255, 134, 64, 255),
        brightness: Brightness.dark,
      ),
      useMaterial3: true,
    ),
  );
}
