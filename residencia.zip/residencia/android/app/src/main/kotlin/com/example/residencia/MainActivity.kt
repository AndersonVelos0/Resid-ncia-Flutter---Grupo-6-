package com.example.residencia

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
